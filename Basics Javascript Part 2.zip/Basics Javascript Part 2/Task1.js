// 1. Define and invoke an anonymous function which takes a number and returns its square.
// If input is 2, output should be 4.

var square = function (num) {
    return num ** 2; // return square of num
}

console.log(square(2)); // Output: 4


// 2. Define an IIFE function which takes a personName as input and displays a greeting message containing the personName.
// If input is "Harry", output should be "Hello Harry, Welcome to Great Learning!"

(function (personName) {
    console.log("Hello " + personName + ", Welcome to Great Learning!");
})('Harry'); // Output: "Hello Harry, Welcome to Great Learning!"


// 3. Define a global array variable containing 3 numbers. 
// Define a function which increments the value of each of the elements of this array by 2. 
// Display the array after you have invoked this function.

var arrayOfNumbers = [2, 4, 6]; // Array of numbers

function incrementByTwo (numbers) {
    for (var i = 0; i < numbers.length; i++) {
        numbers[i] += 2;
    }
    return numbers;
}

arrayOfNumbers = incrementByTwo(arrayOfNumbers); // increment by two and save to array
console.log(arrayOfNumbers); // Output: [4, 6, 8]


// 4. Create a "course" object having following information - 
// courseName as "Computer Science", durationInMonths as 24, level as "Beginner". 
// Display object information.
// Change the value of level as "Intermediate". 
// Display object information again.

var course = {
    courseName: "Computer Science",
    durationInMonths: 24,
    level: "Beginner",
};

console.log(course); // Display object information
course.level = "Intermediate"; // update level to "Intermediate"
console.log(course); // Display updated information


// 5. Given an array "students" of JSON objects write a code to iterate through each of these codes and extract first name and last name of each students.

var students = [
    { firstName: "Harry", lastName: "Potter", house: "Slytherin" },
    { firstName: "Ron", lastName: "Weasley", house: "Gryffindor" },
    { firstName: "Hermione", lastName: "Granger", house: "Gryffindor" }
];

students.forEach((obj) => {
    var name = obj.firstName + " " + obj.lastName;
    console.log(name); // Display first and last name of each students
  });


// 6. Given a function doubleNumber which takes a number as an argument and returns its double value.
// Write a function which takes 2 arguments- 1st an array of numbers and 2nd the doubleNumber function as a callback function
// This function should iterate through each of the array number and use the doubleNumber function to double it.
// In the end it should display the updated array

function doubleNumber(num) {
    return num * 2;
}

function doubleArray(array, doubleNumber) {
    for(var i = 0; i < array.length; i++) {
        array[i] = doubleNumber(array[i]);
    }
    console.log(array); // Displays Output [20, 40, 60, 80, 100]
};

arrayOfNumbers = [10, 20, 30, 40, 50]; // array of numbers given to doubleArray
doubleArray(arrayOfNumbers, doubleNumber); // Call doubleArray


// 7. Implement a function called `multiplyBy` that multiplies a number by a specific factor using an IIFE (Immediately Invoked Function Expression).

(function multipyBy(num1, num2) {
    console.log(num1 * num2);
})(5,5);

//8. Using the `call` method, write a function that finds the maximum number in an array.

function maxNumber(array) {
    var largest = null;
    for(var i = 0; i < array.length; i++) {
        if(array[i] > largest) {
            largest = array[i];
        }
    }
    console.log(largest);
}

var myArray = [5, -80, 30, 15, 35, 44, 18, 40, 2]; 
maxNumber.call(null, myArray);


//9. Declare an object named "car" with an empty object as its initial value. 
// Add the properties "make" and "model" with values "Toyota" and "Camry" respectively.

var car = {};
car.make = "Toyota";
car.model = "Camry";

console.log(car);


//10. Given an array "students" of JSON objects define a function displayByKey which takes this array object 
// and a keyName as string and displays the value of the key for each of the JSON objects.
var students = [
    { firstName: "Harry", lastName: "Potter", house: "Slytherin" },
    { firstName: "Ron", lastName: "Weasley", house: "Gryffindor" },
    { firstName: "Hermione", lastName: "Granger", house: "Gryffindor" }
];

function displayByKey(students, keyName) {
    for(var i = 0; i < students.length; i++) {
        console.log(students[i][keyName]); // Displays all 'values' for any given 'keyName'
    }
}

displayByKey(students, "firstName"); // Get key 'firstName' and get all 'values' in students