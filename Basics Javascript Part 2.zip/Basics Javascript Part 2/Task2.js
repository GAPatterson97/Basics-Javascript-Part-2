// 1. Define 2 functions
// 1st function named as checkEven which will check if the num passed is even or not.
// 2nd function named as filterEvens which will take an array of numbers and the checkEven function as arguments.
// This filterEvens function will filter out  only even numbers using the checkEven function and generate a new array of the even numbers.

function checkEven (num) {
    return num % 2 == 0;
}

function filterEvens (array, checkEven) {
    var newArray = [];
    for(var i = 0; i < array.length; i++) {
        if(checkEven(array[i]) == true) {
            newArray.push(array[i]);
        }
    }
    console.log(newArray);
}

myArray = [1, 2, 3, 4, 6, 8, 9, 10, 11, 13, 15, 16];
filterEvens(myArray, checkEven);


//2. Write an IIFE that calculates the factorial of a given number and immediately logs the result to the console.

(function factorial (num) {
    if(num < 0) {
        console.log('Enter a positive integer');
    } else if(num == 0) {
        console.log(1);
    } else {
        equals = 1;
        for(num; num > 0; num--) {
            equals *= num;
        }
        console.log(equals);
    }
})(5); 

//3. Implement a function "calculate" that takes three arguments: a, b, and an operation function. 
//The operation function should accept two parameters and perform a specific mathematical operation like addition, subtraction, multiplication and division.
//Use call(), apply(), or bind() to apply the operation function to the arguments a and b.

function calculate (a, b, operation) {
    console.log(operation(a, b));
}

function operation (num1, num2) {
    return num1 - num2; // Subtraction
}

calculate.call(null, 5, 2, operation); // Call the calculate function


//4. Given an array of person objects, define a function to find oldest person object.

persons = [{"name" : "Harry", "age" : 12}, {"name" : "Ron", "age" : 11}, {"name" : "Hermione", "age" : 13}]

function oldestPerson (persons) {
    oldest = {name: null, age: null};
    for(var i = 0; i < persons.length; i++) {
        if(persons[i].age > oldest.age) {
            oldest.name = persons[i].name; // Set oldest person name
            oldest.age = persons[i].age; // Set oldest person age
        }
    }
    console.log(oldest); // Display oldest person and age
}

oldestPerson(persons); // Call oldestPerson


//5.  Create a function that calculates the sum of an array using IIFE function.

(function sum (array) {
    var sum = 0;
    for(var i = 0; i < array.length; i++) {
        sum += array[i];
    }
    console.log(sum);
})([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]);


//6. Write a function printContext that, when invoked, logs the this keyword to the console. Then, demonstrate how the context of a function can change when calling it with different objects using the call method.

function printContext() {
    console.log( this );
}

printContext.call("How are you today?");
printContext.call("I am learn Javascript.");
printContext.call("Welcome to Great Learning!");
printContext.call(true);


//7. Create a function multiply that takes two parameters and returns their product. Use the bind method to create a new function "double" that multiplies a single parameter by 2.

function multiply (num1, num2) {
    console.log(num1 * num2);
}

var double = multiply.bind(null, 2);

multiply(2, 3); // Output: 6
double(5); // Output: 10

// 8. Create an object person with properties name and age. Write a function "introduce" that logs a message introducing the person. Then, use the call method to invoke the introduce function with the person object as the context.

var person = {
    name: "Luke Skywalker",
    age: 35,
}

function introduce () {
    console.log("Hello, I am " + person.name + "! " + "I am " + person.age + ".");
}

introduce.call(person); // introduce person oject as the context

// 9. Write a higher order function createMultiplier that takes a factor as an argument and returns another functiom that multiplies a number by that factor. 

function createMultiplier(factor) {
    function answer () {
        console.log(2 * factor);
    }
    return answer(); // returns the function 'answer'
}

createMultiplier(25); // Output: 50


// 10. Write a function called "calculate" that adds two numbers and assign a property "description" to it with a string describing what the function does. Then, access and log this property.

function calculateSum (num1, num2) {
    var summation = { 
        sum: num1 + num2,
        description: "The addition of the two arguments passed to this function.",
    }
    console.log(summation.sum + "  " + summation.description);
}

calculateSum(20, 10); // Output: 30 followed by description of function